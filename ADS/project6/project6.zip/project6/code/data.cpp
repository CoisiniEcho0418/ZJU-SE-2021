#include <bits/stdc++.h>
#include "defs.h"
using namespace std;
extern vector<Rectangle>data;
extern int max_width;
void GenerateData(int size)
{
    data.clear();       /* Clear data */
    srand((unsigned)time(NULL));
    int i;
    for (i = 0; i < size; i++) {
        int a = ((rand() % MAX_HEIGHT) * (rand() % MAX_HEIGHT)) % MAX_HEIGHT;
        int b = ((rand() % max_width) * (rand() % max_width)) % max_width;
        if (a == 0 || b == 0) {     /* width/height 0 is invalid data, we skip it and generate again. */
            i --;
            continue;
        }
        data.push_back(Rectangle(a, b));
    }
    ofstream out("./data.txt");     /* output data so that we can debug. */
    out << size << endl;
    for (auto tmp : data) {
        out << tmp.GetHeight() << " " << tmp.GetWidth() << endl;
    }
}
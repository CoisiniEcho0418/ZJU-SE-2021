## Build & Run

------

可执行文件位置（相对项目根目录路径）：./out/artifacts/WebServer_jar/WebServer.jar （其他中间编译文件已删除）

源代码在项目根目录的src文件夹下

资源文件在项目根目录的source文件夹下

![image-20240102001610022](C:\Users\11\AppData\Roaming\Typora\typora-user-images\image-20240102001610022.png)



> Tips： JDK版本如下图所示
>
> ![image-20240102001542233](C:\Users\11\AppData\Roaming\Typora\typora-user-images\image-20240102001542233.png)
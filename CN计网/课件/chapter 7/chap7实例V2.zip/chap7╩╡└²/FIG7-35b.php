
<html>
<body>
<hl> Reply: </hl>
Hello <?php echo $name; ?>.
Prediction: next year you will be <?php echo $age + 1; ?>
</body>
</html>
 


<html>
<body>
<hl> Reply: </hl>
Hello <?php echo $name; ?>.
Prediction: next year you will be <?php echo Sage + 1; ?>
</body>
</html>
 

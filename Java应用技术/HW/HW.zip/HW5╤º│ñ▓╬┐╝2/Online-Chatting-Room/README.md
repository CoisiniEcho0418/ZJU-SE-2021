- 将homework5_lx_3180106148导入到Eclipse后可以直接运行。
- java文件放在homework5_lx_3180106148\src\online_chatting_room中


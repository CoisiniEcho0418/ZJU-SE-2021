package online_chatting_room;

/* This class contains the main() function of client program */
public class Client_main {
	
	public static Client_Login_GUI client;
	
    public static void main(String[] args) {
    	//Create an instance of Client_Login_GUI
    	client = new Client_Login_GUI();;
    }
}

package online_chatting_room;

/* This class contains the main() function of server program */
public class Server_main {
	public static Server_GUI server;
	
    public static void main(String[] args) {
    	//Create an instance of Server_GUI
    	server = new Server_GUI();
    }
}

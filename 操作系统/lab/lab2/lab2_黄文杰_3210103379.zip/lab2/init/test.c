#include "printk.h"
#include "defs.h"

// Please do not modify

void test() {
    while (1);
}

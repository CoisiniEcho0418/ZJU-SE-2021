#ifndef _CLOCK_H
#define _CLOCK_H
unsigned long get_cycles();
void clock_set_next_event();
#endif
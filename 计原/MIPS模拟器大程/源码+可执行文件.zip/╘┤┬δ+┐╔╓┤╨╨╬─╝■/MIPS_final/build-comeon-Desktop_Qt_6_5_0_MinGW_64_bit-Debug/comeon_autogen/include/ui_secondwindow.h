/********************************************************************************
** Form generated from reading UI file 'secondwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SECONDWINDOW_H
#define UI_SECONDWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Secondwindow
{
public:
    QLabel *label_8;
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QLabel *label;
    QLabel *label_6;
    QLabel *label_3;
    QPushButton *pushButton;
    QLineEdit *lineEdit;
    QLabel *label_7;
    QLabel *label_2;
    QLabel *label_5;
    QLabel *label_9;
    QLabel *label_4;
    QLabel *label_10;
    QWidget *gridLayoutWidget_2;
    QGridLayout *gridLayout_2;
    QLabel *label_18;
    QLineEdit *lineEdit_2;
    QLabel *label_11;
    QLabel *label_15;
    QPushButton *pushButton_2;
    QLabel *label_12;
    QLabel *label_13;
    QWidget *gridLayoutWidget_3;
    QGridLayout *gridLayout_3;
    QLabel *label_19;
    QLabel *label_21;
    QPushButton *pushButton_3;
    QLabel *label_22;
    QLabel *label_23;
    QLabel *label_14;
    QLineEdit *lineEdit_3;
    QLabel *label_20;
    QLabel *label_16;
    QLabel *label_17;
    QLabel *label_24;
    QLabel *label_34;
    QWidget *gridLayoutWidget_4;
    QGridLayout *gridLayout_5;
    QLabel *label_35;
    QLabel *label_36;
    QPushButton *pushButton_5;
    QLabel *label_37;
    QLabel *label_38;
    QLabel *label_39;
    QLineEdit *lineEdit_5;
    QLabel *label_40;
    QLabel *label_41;
    QLabel *label_42;
    QLabel *label_43;
    QLabel *label_44;
    QWidget *gridLayoutWidget_5;
    QGridLayout *gridLayout_6;
    QLabel *label_45;
    QLineEdit *lineEdit_6;
    QLabel *label_46;
    QLabel *label_47;
    QPushButton *pushButton_6;
    QLabel *label_48;
    QLabel *label_49;
    QWidget *gridLayoutWidget_6;
    QGridLayout *gridLayout_7;
    QLabel *label_50;
    QLineEdit *lineEdit_7;
    QLabel *label_51;
    QLabel *label_52;
    QPushButton *pushButton_7;
    QLabel *label_53;
    QLabel *label_54;
    QWidget *gridLayoutWidget_7;
    QGridLayout *gridLayout_8;
    QTextEdit *textEdit;
    QComboBox *comboBox;
    QLabel *label_57;
    QPushButton *pushButton_8;
    QLabel *label_58;
    QLabel *label_64;
    QLabel *label_60;
    QLabel *label_59;
    QLabel *label_56;
    QTextEdit *textEdit_2;
    QTextEdit *textEdit_3;
    QLineEdit *lineEdit_8;
    QLabel *label_55;
    QLabel *label_61;
    QPushButton *pushButton_9;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label_62;
    QLabel *label_63;
    QLabel *label_65;
    QLabel *label_66;
    QLabel *label_67;
    QLabel *label_68;
    QLabel *label_69;
    QLabel *label_70;

    void setupUi(QWidget *Secondwindow)
    {
        if (Secondwindow->objectName().isEmpty())
            Secondwindow->setObjectName("Secondwindow");
        Secondwindow->resize(1268, 786);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(Secondwindow->sizePolicy().hasHeightForWidth());
        Secondwindow->setSizePolicy(sizePolicy);
        label_8 = new QLabel(Secondwindow);
        label_8->setObjectName("label_8");
        label_8->setGeometry(QRect(20, 20, 391, 201));
        label_8->setAutoFillBackground(false);
        label_8->setStyleSheet(QString::fromUtf8("background-color: rgba(0, 255, 255, 10);"));
        gridLayoutWidget = new QWidget(Secondwindow);
        gridLayoutWidget->setObjectName("gridLayoutWidget");
        gridLayoutWidget->setGeometry(QRect(30, 30, 371, 181));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setObjectName("gridLayout");
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(gridLayoutWidget);
        label->setObjectName("label");
        label->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label, 1, 0, 1, 1);

        label_6 = new QLabel(gridLayoutWidget);
        label_6->setObjectName("label_6");
        label_6->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_6, 4, 0, 1, 1);

        label_3 = new QLabel(gridLayoutWidget);
        label_3->setObjectName("label_3");

        gridLayout->addWidget(label_3, 2, 1, 1, 1);

        pushButton = new QPushButton(gridLayoutWidget);
        pushButton->setObjectName("pushButton");

        gridLayout->addWidget(pushButton, 5, 0, 1, 1);

        lineEdit = new QLineEdit(gridLayoutWidget);
        lineEdit->setObjectName("lineEdit");

        gridLayout->addWidget(lineEdit, 1, 1, 1, 1);

        label_7 = new QLabel(gridLayoutWidget);
        label_7->setObjectName("label_7");

        gridLayout->addWidget(label_7, 4, 1, 1, 1);

        label_2 = new QLabel(gridLayoutWidget);
        label_2->setObjectName("label_2");
        label_2->setLayoutDirection(Qt::LeftToRight);
        label_2->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_2, 2, 0, 1, 1);

        label_5 = new QLabel(gridLayoutWidget);
        label_5->setObjectName("label_5");

        gridLayout->addWidget(label_5, 3, 1, 1, 1);

        label_9 = new QLabel(gridLayoutWidget);
        label_9->setObjectName("label_9");
        QFont font;
        font.setPointSize(14);
        font.setBold(true);
        label_9->setFont(font);

        gridLayout->addWidget(label_9, 0, 0, 1, 2);

        label_4 = new QLabel(gridLayoutWidget);
        label_4->setObjectName("label_4");
        label_4->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_4, 3, 0, 1, 1);

        label_10 = new QLabel(Secondwindow);
        label_10->setObjectName("label_10");
        label_10->setGeometry(QRect(20, 230, 391, 161));
        label_10->setAutoFillBackground(false);
        label_10->setStyleSheet(QString::fromUtf8("background-color: rgba(0, 255, 255, 10);"));
        gridLayoutWidget_2 = new QWidget(Secondwindow);
        gridLayoutWidget_2->setObjectName("gridLayoutWidget_2");
        gridLayoutWidget_2->setGeometry(QRect(30, 240, 371, 141));
        gridLayout_2 = new QGridLayout(gridLayoutWidget_2);
        gridLayout_2->setObjectName("gridLayout_2");
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        label_18 = new QLabel(gridLayoutWidget_2);
        label_18->setObjectName("label_18");
        label_18->setFont(font);

        gridLayout_2->addWidget(label_18, 0, 0, 1, 2);

        lineEdit_2 = new QLineEdit(gridLayoutWidget_2);
        lineEdit_2->setObjectName("lineEdit_2");

        gridLayout_2->addWidget(lineEdit_2, 1, 1, 1, 1);

        label_11 = new QLabel(gridLayoutWidget_2);
        label_11->setObjectName("label_11");
        label_11->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_11, 1, 0, 1, 1);

        label_15 = new QLabel(gridLayoutWidget_2);
        label_15->setObjectName("label_15");

        gridLayout_2->addWidget(label_15, 2, 1, 1, 1);

        pushButton_2 = new QPushButton(gridLayoutWidget_2);
        pushButton_2->setObjectName("pushButton_2");

        gridLayout_2->addWidget(pushButton_2, 3, 0, 1, 1);

        label_12 = new QLabel(gridLayoutWidget_2);
        label_12->setObjectName("label_12");
        label_12->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_12, 2, 0, 1, 1);

        label_13 = new QLabel(Secondwindow);
        label_13->setObjectName("label_13");
        label_13->setGeometry(QRect(420, 20, 391, 201));
        label_13->setAutoFillBackground(false);
        label_13->setStyleSheet(QString::fromUtf8("background-color: rgba(255, 0, 255, 10);"));
        gridLayoutWidget_3 = new QWidget(Secondwindow);
        gridLayoutWidget_3->setObjectName("gridLayoutWidget_3");
        gridLayoutWidget_3->setGeometry(QRect(430, 30, 371, 181));
        gridLayout_3 = new QGridLayout(gridLayoutWidget_3);
        gridLayout_3->setObjectName("gridLayout_3");
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        label_19 = new QLabel(gridLayoutWidget_3);
        label_19->setObjectName("label_19");
        label_19->setStyleSheet(QString::fromUtf8("color: rgb(255, 0, 0);"));

        gridLayout_3->addWidget(label_19, 5, 1, 1, 1);

        label_21 = new QLabel(gridLayoutWidget_3);
        label_21->setObjectName("label_21");
        label_21->setLayoutDirection(Qt::LeftToRight);
        label_21->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(label_21, 2, 0, 1, 1);

        pushButton_3 = new QPushButton(gridLayoutWidget_3);
        pushButton_3->setObjectName("pushButton_3");

        gridLayout_3->addWidget(pushButton_3, 5, 0, 1, 1);

        label_22 = new QLabel(gridLayoutWidget_3);
        label_22->setObjectName("label_22");
        label_22->setLayoutDirection(Qt::LeftToRight);
        label_22->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(label_22, 3, 0, 1, 1);

        label_23 = new QLabel(gridLayoutWidget_3);
        label_23->setObjectName("label_23");
        label_23->setFont(font);

        gridLayout_3->addWidget(label_23, 0, 0, 1, 2);

        label_14 = new QLabel(gridLayoutWidget_3);
        label_14->setObjectName("label_14");
        label_14->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(label_14, 1, 0, 1, 1);

        lineEdit_3 = new QLineEdit(gridLayoutWidget_3);
        lineEdit_3->setObjectName("lineEdit_3");

        gridLayout_3->addWidget(lineEdit_3, 1, 1, 1, 1);

        label_20 = new QLabel(gridLayoutWidget_3);
        label_20->setObjectName("label_20");
        label_20->setLayoutDirection(Qt::LeftToRight);
        label_20->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(label_20, 4, 0, 1, 1);

        label_16 = new QLabel(gridLayoutWidget_3);
        label_16->setObjectName("label_16");

        gridLayout_3->addWidget(label_16, 2, 1, 1, 1);

        label_17 = new QLabel(gridLayoutWidget_3);
        label_17->setObjectName("label_17");

        gridLayout_3->addWidget(label_17, 3, 1, 1, 1);

        label_24 = new QLabel(gridLayoutWidget_3);
        label_24->setObjectName("label_24");

        gridLayout_3->addWidget(label_24, 4, 1, 1, 1);

        label_34 = new QLabel(Secondwindow);
        label_34->setObjectName("label_34");
        label_34->setGeometry(QRect(20, 400, 791, 201));
        label_34->setAutoFillBackground(false);
        label_34->setStyleSheet(QString::fromUtf8("background-color: rgba(255, 255, 0, 10);"));
        gridLayoutWidget_4 = new QWidget(Secondwindow);
        gridLayoutWidget_4->setObjectName("gridLayoutWidget_4");
        gridLayoutWidget_4->setGeometry(QRect(30, 410, 771, 181));
        gridLayout_5 = new QGridLayout(gridLayoutWidget_4);
        gridLayout_5->setObjectName("gridLayout_5");
        gridLayout_5->setContentsMargins(0, 0, 0, 0);
        label_35 = new QLabel(gridLayoutWidget_4);
        label_35->setObjectName("label_35");
        label_35->setStyleSheet(QString::fromUtf8("color: rgb(255, 0, 0);"));

        gridLayout_5->addWidget(label_35, 5, 1, 1, 1);

        label_36 = new QLabel(gridLayoutWidget_4);
        label_36->setObjectName("label_36");
        label_36->setLayoutDirection(Qt::LeftToRight);
        label_36->setAlignment(Qt::AlignCenter);

        gridLayout_5->addWidget(label_36, 2, 0, 1, 1);

        pushButton_5 = new QPushButton(gridLayoutWidget_4);
        pushButton_5->setObjectName("pushButton_5");

        gridLayout_5->addWidget(pushButton_5, 5, 0, 1, 1);

        label_37 = new QLabel(gridLayoutWidget_4);
        label_37->setObjectName("label_37");
        label_37->setLayoutDirection(Qt::LeftToRight);
        label_37->setAlignment(Qt::AlignCenter);

        gridLayout_5->addWidget(label_37, 3, 0, 1, 1);

        label_38 = new QLabel(gridLayoutWidget_4);
        label_38->setObjectName("label_38");
        label_38->setFont(font);

        gridLayout_5->addWidget(label_38, 0, 0, 1, 2);

        label_39 = new QLabel(gridLayoutWidget_4);
        label_39->setObjectName("label_39");
        label_39->setAlignment(Qt::AlignCenter);

        gridLayout_5->addWidget(label_39, 1, 0, 1, 1);

        lineEdit_5 = new QLineEdit(gridLayoutWidget_4);
        lineEdit_5->setObjectName("lineEdit_5");

        gridLayout_5->addWidget(lineEdit_5, 1, 1, 1, 1);

        label_40 = new QLabel(gridLayoutWidget_4);
        label_40->setObjectName("label_40");
        label_40->setLayoutDirection(Qt::LeftToRight);
        label_40->setAlignment(Qt::AlignCenter);

        gridLayout_5->addWidget(label_40, 4, 0, 1, 1);

        label_41 = new QLabel(gridLayoutWidget_4);
        label_41->setObjectName("label_41");

        gridLayout_5->addWidget(label_41, 2, 1, 1, 1);

        label_42 = new QLabel(gridLayoutWidget_4);
        label_42->setObjectName("label_42");

        gridLayout_5->addWidget(label_42, 3, 1, 1, 1);

        label_43 = new QLabel(gridLayoutWidget_4);
        label_43->setObjectName("label_43");

        gridLayout_5->addWidget(label_43, 4, 1, 1, 1);

        label_44 = new QLabel(Secondwindow);
        label_44->setObjectName("label_44");
        label_44->setGeometry(QRect(420, 230, 391, 161));
        label_44->setAutoFillBackground(false);
        label_44->setStyleSheet(QString::fromUtf8("background-color: rgba(255, 0, 255, 10);"));
        gridLayoutWidget_5 = new QWidget(Secondwindow);
        gridLayoutWidget_5->setObjectName("gridLayoutWidget_5");
        gridLayoutWidget_5->setGeometry(QRect(430, 240, 371, 141));
        gridLayout_6 = new QGridLayout(gridLayoutWidget_5);
        gridLayout_6->setObjectName("gridLayout_6");
        gridLayout_6->setContentsMargins(0, 0, 0, 0);
        label_45 = new QLabel(gridLayoutWidget_5);
        label_45->setObjectName("label_45");
        label_45->setFont(font);

        gridLayout_6->addWidget(label_45, 0, 0, 1, 2);

        lineEdit_6 = new QLineEdit(gridLayoutWidget_5);
        lineEdit_6->setObjectName("lineEdit_6");

        gridLayout_6->addWidget(lineEdit_6, 1, 1, 1, 1);

        label_46 = new QLabel(gridLayoutWidget_5);
        label_46->setObjectName("label_46");
        label_46->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(label_46, 1, 0, 1, 1);

        label_47 = new QLabel(gridLayoutWidget_5);
        label_47->setObjectName("label_47");

        gridLayout_6->addWidget(label_47, 2, 1, 1, 1);

        pushButton_6 = new QPushButton(gridLayoutWidget_5);
        pushButton_6->setObjectName("pushButton_6");

        gridLayout_6->addWidget(pushButton_6, 3, 0, 1, 1);

        label_48 = new QLabel(gridLayoutWidget_5);
        label_48->setObjectName("label_48");
        label_48->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(label_48, 2, 0, 1, 1);

        label_49 = new QLabel(Secondwindow);
        label_49->setObjectName("label_49");
        label_49->setGeometry(QRect(20, 610, 791, 151));
        label_49->setAutoFillBackground(false);
        label_49->setStyleSheet(QString::fromUtf8("background-color: rgba(255, 255, 0, 10);"));
        gridLayoutWidget_6 = new QWidget(Secondwindow);
        gridLayoutWidget_6->setObjectName("gridLayoutWidget_6");
        gridLayoutWidget_6->setGeometry(QRect(30, 620, 771, 131));
        gridLayout_7 = new QGridLayout(gridLayoutWidget_6);
        gridLayout_7->setObjectName("gridLayout_7");
        gridLayout_7->setContentsMargins(0, 0, 0, 0);
        label_50 = new QLabel(gridLayoutWidget_6);
        label_50->setObjectName("label_50");
        label_50->setFont(font);

        gridLayout_7->addWidget(label_50, 0, 0, 1, 2);

        lineEdit_7 = new QLineEdit(gridLayoutWidget_6);
        lineEdit_7->setObjectName("lineEdit_7");

        gridLayout_7->addWidget(lineEdit_7, 1, 1, 1, 1);

        label_51 = new QLabel(gridLayoutWidget_6);
        label_51->setObjectName("label_51");
        label_51->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(label_51, 1, 0, 1, 1);

        label_52 = new QLabel(gridLayoutWidget_6);
        label_52->setObjectName("label_52");

        gridLayout_7->addWidget(label_52, 2, 1, 1, 1);

        pushButton_7 = new QPushButton(gridLayoutWidget_6);
        pushButton_7->setObjectName("pushButton_7");

        gridLayout_7->addWidget(pushButton_7, 3, 0, 1, 1);

        label_53 = new QLabel(gridLayoutWidget_6);
        label_53->setObjectName("label_53");
        label_53->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(label_53, 2, 0, 1, 1);

        label_54 = new QLabel(Secondwindow);
        label_54->setObjectName("label_54");
        label_54->setGeometry(QRect(820, 20, 431, 281));
        label_54->setAutoFillBackground(false);
        label_54->setStyleSheet(QString::fromUtf8("background-color: rgba(100, 0, 200, 10);"));
        gridLayoutWidget_7 = new QWidget(Secondwindow);
        gridLayoutWidget_7->setObjectName("gridLayoutWidget_7");
        gridLayoutWidget_7->setGeometry(QRect(830, 30, 411, 261));
        gridLayout_8 = new QGridLayout(gridLayoutWidget_7);
        gridLayout_8->setObjectName("gridLayout_8");
        gridLayout_8->setContentsMargins(0, 0, 0, 0);
        textEdit = new QTextEdit(gridLayoutWidget_7);
        textEdit->setObjectName("textEdit");
        textEdit->setLineWrapMode(QTextEdit::NoWrap);
        textEdit->setLineWrapColumnOrWidth(1);
        textEdit->setReadOnly(true);

        gridLayout_8->addWidget(textEdit, 4, 1, 1, 1);

        comboBox = new QComboBox(gridLayoutWidget_7);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName("comboBox");
        comboBox->setEnabled(true);
        comboBox->setEditable(false);

        gridLayout_8->addWidget(comboBox, 2, 1, 1, 1);

        label_57 = new QLabel(gridLayoutWidget_7);
        label_57->setObjectName("label_57");
        label_57->setLayoutDirection(Qt::LeftToRight);
        label_57->setAlignment(Qt::AlignCenter);

        gridLayout_8->addWidget(label_57, 4, 0, 1, 1);

        pushButton_8 = new QPushButton(gridLayoutWidget_7);
        pushButton_8->setObjectName("pushButton_8");

        gridLayout_8->addWidget(pushButton_8, 7, 0, 1, 1);

        label_58 = new QLabel(gridLayoutWidget_7);
        label_58->setObjectName("label_58");
        label_58->setFont(font);
        label_58->setAlignment(Qt::AlignCenter);

        gridLayout_8->addWidget(label_58, 0, 0, 1, 2);

        label_64 = new QLabel(gridLayoutWidget_7);
        label_64->setObjectName("label_64");
        label_64->setLayoutDirection(Qt::LeftToRight);
        label_64->setAlignment(Qt::AlignCenter);

        gridLayout_8->addWidget(label_64, 5, 0, 1, 1);

        label_60 = new QLabel(gridLayoutWidget_7);
        label_60->setObjectName("label_60");
        label_60->setLayoutDirection(Qt::LeftToRight);
        label_60->setAlignment(Qt::AlignCenter);

        gridLayout_8->addWidget(label_60, 6, 0, 1, 1);

        label_59 = new QLabel(gridLayoutWidget_7);
        label_59->setObjectName("label_59");
        label_59->setAlignment(Qt::AlignCenter);

        gridLayout_8->addWidget(label_59, 2, 0, 1, 1);

        label_56 = new QLabel(gridLayoutWidget_7);
        label_56->setObjectName("label_56");
        label_56->setLayoutDirection(Qt::LeftToRight);
        label_56->setAlignment(Qt::AlignCenter);

        gridLayout_8->addWidget(label_56, 3, 0, 1, 1);

        textEdit_2 = new QTextEdit(gridLayoutWidget_7);
        textEdit_2->setObjectName("textEdit_2");
        textEdit_2->setLineWrapMode(QTextEdit::NoWrap);
        textEdit_2->setLineWrapColumnOrWidth(1);
        textEdit_2->setReadOnly(true);

        gridLayout_8->addWidget(textEdit_2, 5, 1, 1, 1);

        textEdit_3 = new QTextEdit(gridLayoutWidget_7);
        textEdit_3->setObjectName("textEdit_3");
        textEdit_3->setLineWrapMode(QTextEdit::NoWrap);
        textEdit_3->setLineWrapColumnOrWidth(1);
        textEdit_3->setReadOnly(true);

        gridLayout_8->addWidget(textEdit_3, 6, 1, 1, 1);

        lineEdit_8 = new QLineEdit(gridLayoutWidget_7);
        lineEdit_8->setObjectName("lineEdit_8");

        gridLayout_8->addWidget(lineEdit_8, 3, 1, 1, 1);

        label_55 = new QLabel(gridLayoutWidget_7);
        label_55->setObjectName("label_55");
        label_55->setStyleSheet(QString::fromUtf8(""));

        gridLayout_8->addWidget(label_55, 7, 1, 1, 1);

        label_61 = new QLabel(Secondwindow);
        label_61->setObjectName("label_61");
        label_61->setGeometry(QRect(820, 310, 431, 451));
        label_61->setAutoFillBackground(false);
        label_61->setStyleSheet(QString::fromUtf8("background-color: rgba(255, 255, 255, 255);"));
        pushButton_9 = new QPushButton(Secondwindow);
        pushButton_9->setObjectName("pushButton_9");
        pushButton_9->setGeometry(QRect(1130, 730, 115, 26));
        pushButton_9->setStyleSheet(QString::fromUtf8("background-color: rgba(170, 170, 255, 50);"));
        layoutWidget = new QWidget(Secondwindow);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(830, 320, 411, 401));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_62 = new QLabel(layoutWidget);
        label_62->setObjectName("label_62");
        label_62->setFont(font);
        label_62->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_62);

        label_63 = new QLabel(layoutWidget);
        label_63->setObjectName("label_63");
        QFont font1;
        font1.setPointSize(9);
        font1.setBold(false);
        label_63->setFont(font1);
        label_63->setWordWrap(true);

        verticalLayout->addWidget(label_63);

        label_65 = new QLabel(layoutWidget);
        label_65->setObjectName("label_65");
        label_65->setFont(font1);
        label_65->setWordWrap(true);

        verticalLayout->addWidget(label_65);

        label_66 = new QLabel(layoutWidget);
        label_66->setObjectName("label_66");
        label_66->setFont(font1);
        label_66->setWordWrap(true);

        verticalLayout->addWidget(label_66);

        label_67 = new QLabel(layoutWidget);
        label_67->setObjectName("label_67");
        label_67->setFont(font1);
        label_67->setWordWrap(true);

        verticalLayout->addWidget(label_67);

        label_68 = new QLabel(layoutWidget);
        label_68->setObjectName("label_68");
        label_68->setFont(font1);
        label_68->setWordWrap(true);

        verticalLayout->addWidget(label_68);

        label_69 = new QLabel(layoutWidget);
        label_69->setObjectName("label_69");
        label_69->setFont(font1);
        label_69->setWordWrap(true);

        verticalLayout->addWidget(label_69);

        label_70 = new QLabel(layoutWidget);
        label_70->setObjectName("label_70");
        label_70->setFont(font1);
        label_70->setWordWrap(true);

        verticalLayout->addWidget(label_70);


        retranslateUi(Secondwindow);

        comboBox->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Secondwindow);
    } // setupUi

    void retranslateUi(QWidget *Secondwindow)
    {
        Secondwindow->setWindowTitle(QCoreApplication::translate("Secondwindow", "Form", nullptr));
        label_8->setText(QString());
        label->setText(QCoreApplication::translate("Secondwindow", "\350\257\267\350\276\223\345\205\245\346\225\264\346\225\260\357\274\232", nullptr));
        label_6->setText(QCoreApplication::translate("Secondwindow", " \350\241\245          \347\240\201\357\274\232", nullptr));
        label_3->setText(QString());
        pushButton->setText(QCoreApplication::translate("Secondwindow", "\345\274\200\345\247\213\350\275\254\346\215\242", nullptr));
        label_7->setText(QString());
        label_2->setText(QCoreApplication::translate("Secondwindow", " \345\216\237          \347\240\201\357\274\232", nullptr));
        label_5->setText(QString());
        label_9->setText(QCoreApplication::translate("Secondwindow", "\346\234\211\347\254\246\345\217\267\346\225\264\346\225\260\347\232\204\345\216\237\347\240\201\343\200\201\345\217\215\347\240\201\343\200\201\350\241\245\347\240\201\350\241\250\347\244\272", nullptr));
        label_4->setText(QCoreApplication::translate("Secondwindow", " \345\217\215          \347\240\201\357\274\232", nullptr));
        label_10->setText(QString());
        label_18->setText(QCoreApplication::translate("Secondwindow", "32\344\275\215\344\272\214\350\277\233\345\210\266\350\241\245\347\240\201\350\275\254\346\234\211\347\254\246\345\217\267\346\225\264\346\225\260", nullptr));
        label_11->setText(QCoreApplication::translate("Secondwindow", "\350\257\267\350\276\223\345\205\24532\344\275\215\350\241\245\347\240\201\357\274\232", nullptr));
        label_15->setText(QString());
        pushButton_2->setText(QCoreApplication::translate("Secondwindow", "\345\274\200\345\247\213\350\275\254\346\215\242", nullptr));
        label_12->setText(QCoreApplication::translate("Secondwindow", "\345\257\271\345\272\224\346\225\264\346\225\260\344\270\272\357\274\232", nullptr));
        label_13->setText(QString());
        label_19->setText(QString());
        label_21->setText(QCoreApplication::translate("Secondwindow", "\345\215\201\350\277\233\345\210\266\350\241\250\347\244\272\357\274\232", nullptr));
        pushButton_3->setText(QCoreApplication::translate("Secondwindow", "\345\274\200\345\247\213\350\275\254\346\215\242", nullptr));
        label_22->setText(QCoreApplication::translate("Secondwindow", "\344\272\214\350\277\233\345\210\266\350\241\250\347\244\272\357\274\232", nullptr));
        label_23->setText(QCoreApplication::translate("Secondwindow", "\345\215\225\347\262\276\345\272\246\346\265\256\347\202\271\346\225\260\347\232\204IEEE754\350\241\250\347\244\272", nullptr));
        label_14->setText(QCoreApplication::translate("Secondwindow", "\350\257\267\350\276\223\345\205\245float\346\225\260\357\274\232", nullptr));
        label_20->setText(QCoreApplication::translate("Secondwindow", "\345\215\201\345\205\255\350\277\233\345\210\266\350\241\250\347\244\272\357\274\232", nullptr));
        label_16->setText(QString());
        label_17->setText(QString());
        label_24->setText(QString());
        label_34->setText(QString());
        label_35->setText(QString());
        label_36->setText(QCoreApplication::translate("Secondwindow", "\345\215\201\350\277\233\345\210\266\350\241\250\347\244\272\357\274\232", nullptr));
        pushButton_5->setText(QCoreApplication::translate("Secondwindow", "\345\274\200\345\247\213\350\275\254\346\215\242", nullptr));
        label_37->setText(QCoreApplication::translate("Secondwindow", "\344\272\214\350\277\233\345\210\266\350\241\250\347\244\272\357\274\232", nullptr));
        label_38->setText(QCoreApplication::translate("Secondwindow", "\345\217\214\347\262\276\345\272\246\346\265\256\347\202\271\346\225\260\347\232\204IEEE754\350\241\250\347\244\272", nullptr));
        label_39->setText(QCoreApplication::translate("Secondwindow", "\350\257\267\350\276\223\345\205\245double\346\225\260\357\274\232", nullptr));
        label_40->setText(QCoreApplication::translate("Secondwindow", "\345\215\201\345\205\255\350\277\233\345\210\266\350\241\250\347\244\272\357\274\232", nullptr));
        label_41->setText(QString());
        label_42->setText(QString());
        label_43->setText(QString());
        label_44->setText(QString());
        label_45->setText(QCoreApplication::translate("Secondwindow", "\344\272\214\350\277\233\345\210\266\347\274\226\347\240\201\350\275\254\345\215\225\347\262\276\345\272\246\346\265\256\347\202\271\346\225\260\357\274\210float\357\274\211", nullptr));
        label_46->setText(QCoreApplication::translate("Secondwindow", "\350\257\267\350\276\223\345\205\24532\344\275\215\347\274\226\347\240\201\357\274\232", nullptr));
        label_47->setText(QString());
        pushButton_6->setText(QCoreApplication::translate("Secondwindow", "\345\274\200\345\247\213\350\275\254\346\215\242", nullptr));
        label_48->setText(QCoreApplication::translate("Secondwindow", "\345\257\271\345\272\224\347\232\204float\346\225\260\344\270\272\357\274\232", nullptr));
        label_49->setText(QString());
        label_50->setText(QCoreApplication::translate("Secondwindow", "\344\272\214\350\277\233\345\210\266\347\274\226\347\240\201\350\275\254\345\217\214\347\262\276\345\272\246\346\265\256\347\202\271\346\225\260\357\274\210double\357\274\211", nullptr));
        label_51->setText(QCoreApplication::translate("Secondwindow", "\350\257\267\350\276\223\345\205\24564\344\275\215\347\274\226\347\240\201\357\274\232", nullptr));
        label_52->setText(QString());
        pushButton_7->setText(QCoreApplication::translate("Secondwindow", "\345\274\200\345\247\213\350\275\254\346\215\242", nullptr));
        label_53->setText(QCoreApplication::translate("Secondwindow", "\345\257\271\345\272\224\347\232\204double\346\225\260\344\270\272\357\274\232", nullptr));
        label_54->setText(QString());
        textEdit->setHtml(QCoreApplication::translate("Secondwindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Microsoft YaHei UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", nullptr));
        comboBox->setItemText(0, QCoreApplication::translate("Secondwindow", "\344\272\214\350\277\233\345\210\266", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("Secondwindow", "\345\215\201\350\277\233\345\210\266", nullptr));
        comboBox->setItemText(2, QCoreApplication::translate("Secondwindow", "\345\215\201\345\205\255\350\277\233\345\210\266", nullptr));

        label_57->setText(QCoreApplication::translate("Secondwindow", "\344\272\214\350\277\233\345\210\266\350\241\250\347\244\272\357\274\232", nullptr));
        pushButton_8->setText(QCoreApplication::translate("Secondwindow", "\345\274\200\345\247\213\350\275\254\346\215\242", nullptr));
        label_58->setText(QCoreApplication::translate("Secondwindow", "\350\277\233\345\210\266\350\275\254\346\215\242\345\231\250", nullptr));
        label_64->setText(QCoreApplication::translate("Secondwindow", "\345\215\201\350\277\233\345\210\266\350\241\250\347\244\272\357\274\232", nullptr));
        label_60->setText(QCoreApplication::translate("Secondwindow", "\345\215\201\345\205\255\350\277\233\345\210\266\350\241\250\347\244\272\357\274\232", nullptr));
        label_59->setText(QCoreApplication::translate("Secondwindow", "\350\276\223\345\205\245\350\277\233\345\210\266\351\200\211\346\213\251", nullptr));
        label_56->setText(QCoreApplication::translate("Secondwindow", "\345\276\205\350\275\254\346\215\242\346\225\260\345\255\227", nullptr));
        textEdit_2->setHtml(QCoreApplication::translate("Secondwindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Microsoft YaHei UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", nullptr));
        textEdit_3->setHtml(QCoreApplication::translate("Secondwindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Microsoft YaHei UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", nullptr));
        label_55->setText(QCoreApplication::translate("Secondwindow", "\350\213\245\347\255\224\346\241\210\345\274\202\345\270\270\357\274\214\345\210\231\345\215\201\350\277\233\345\210\266\346\225\260\350\266\205\350\277\207longlongint\347\232\204\350\214\203\345\233\264", nullptr));
        label_61->setText(QString());
        pushButton_9->setText(QCoreApplication::translate("Secondwindow", "Return", nullptr));
        label_62->setText(QCoreApplication::translate("Secondwindow", "<\345\212\237\350\203\275\344\273\213\347\273\215\344\270\216\350\257\264\346\230\216>", nullptr));
        label_63->setText(QCoreApplication::translate("Secondwindow", "1.\343\200\220\346\234\211\347\254\246\345\217\267\346\225\264\346\225\260\347\232\204\345\216\237\347\240\201\343\200\201\345\217\215\347\240\201\343\200\201\350\241\245\347\240\201\350\241\250\347\244\272\343\200\221\350\276\223\345\205\245\344\270\200\344\270\252int\350\214\203\345\233\264\345\206\205\347\232\204\346\225\264\346\225\260\357\274\214\347\202\271\345\207\273\345\274\200\345\247\213\350\275\254\346\215\242\357\274\214\344\274\232\347\224\237\346\210\220\347\233\270\345\272\224\347\232\204\345\216\237\347\240\201\343\200\201\345\217\215\347\240\201\343\200\201\350\241\245\347\240\201\343\200\202", nullptr));
        label_65->setText(QCoreApplication::translate("Secondwindow", "2.\343\200\22032\344\275\215\344\272\214\350\277\233\345\210\266\350\241\245\347\240\201\350\275\254\346\234\211\347\254\246\345\217\267\346\225\264\346\225\260\343\200\221\350\276\223\345\205\245\344\270\200\344\270\25232\344\275\215\344\272\214\350\277\233\345\210\266\350\241\245\347\240\201\357\274\214\347\202\271\345\207\273\345\274\200\345\247\213\350\275\254\346\215\242\357\274\214\344\274\232\347\224\237\346\210\220\350\257\245\350\241\245\347\240\201\345\257\271\345\272\224\347\232\204\345\270\246\347\254\246\345\217\267\346\225\264\346\225\260\343\200\202", nullptr));
        label_66->setText(QCoreApplication::translate("Secondwindow", "3.\343\200\220\345\215\225\347\262\276\345\272\246\346\265\256\347\202\271\346\225\260\347\232\204IEEE754\350\241\250\347\244\272\343\200\221\350\276\223\345\205\245\344\270\200\344\270\252float\346\225\260\357\274\210\350\213\245\351\235\236float\346\225\260\344\274\232\350\207\252\345\212\250\350\277\221\344\274\274\345\210\260\346\234\200\351\202\273\350\277\221\347\232\204float\346\225\260\357\274\211\357\274\214\347\202\271\345\207\273\345\274\200\345\247\213\350\275\254\346\215\242\357\274\214\344\274\232\347\224\237\346\210\220IEEE754\346\240\207\345\207\206\344\270\213\347\232\204\344\272\214\350\277\233\345\210\266\345\222\214\345\215\201\345\205\255\350\277\233\345\210\266\350\241\250\347\244\272\343\200\202", nullptr));
        label_67->setText(QCoreApplication::translate("Secondwindow", "4.\343\200\220\344\272\214\350\277\233\345\210\266\347\274\226\347\240\201\350\275\254\345\215\225\347\262\276\345\272\246\346\265\256\347\202\271\346\225\260\357\274\210float\357\274\211\343\200\221\350\276\223\345\205\245\344\270\200\344\270\25232\344\275\215IEEE754\346\240\207\345\207\206\347\232\204\344\272\214\350\277\233\345\210\266\347\274\226\347\240\201\357\274\214\347\202\271\345\207\273\345\274\200\345\247\213\350\275\254\346\215\242\357\274\214\344\274\232\347\224\237\346\210\220\350\257\245\347\274\226\347\240\201\350\241\250\347\244\272\347\232\204float\346\225\260\343\200\202", nullptr));
        label_68->setText(QCoreApplication::translate("Secondwindow", "5.\343\200\220\345\217\214\347\262\276\345\272\246\346\265\256\347\202\271\346\225\260\347\232\204IEEE754\350\241\250\347\244\272\343\200\221\350\276\223\345\205\245\344\270\200\344\270\252double\346\225\260\357\274\210\350\213\245\351\235\236double\346\225\260\344\274\232\350\207\252\345\212\250\350\277\221\344\274\274\345\210\260\346\234\200\351\202\273\350\277\221\347\232\204double\346\225\260\357\274\211\357\274\214\347\202\271\345\207\273\345\274\200\345\247\213\350\275\254\346\215\242\357\274\214\344\274\232\347\224\237\346\210\220IEEE754\346\240\207\345\207\206\344\270\213\347\232\204\344\272\214\350\277\233\345\210\266\345\222\214\345\215\201\345\205\255\350\277\233\345\210\266\350\241\250\347\244\272\343\200\202", nullptr));
        label_69->setText(QCoreApplication::translate("Secondwindow", "6.\343\200\220\344\272\214\350\277\233\345\210\266\347\274\226\347\240\201\350\275\254\345\215\225\347\262\276\345\272\246\346\265\256\347\202\271\346\225\260\357\274\210double\357\274\211\343\200\221\350\276\223\345\205\245\344\270\200\344\270\25264\344\275\215IEEE754\346\240\207\345\207\206\347\232\204\344\272\214\350\277\233\345\210\266\347\274\226\347\240\201\357\274\214\347\202\271\345\207\273\345\274\200\345\247\213\350\275\254\346\215\242\357\274\214\344\274\232\347\224\237\346\210\220\350\257\245\347\274\226\347\240\201\350\241\250\347\244\272\347\232\204double\346\225\260\343\200\202", nullptr));
        label_70->setText(QCoreApplication::translate("Secondwindow", "7.\343\200\220\350\277\233\345\210\266\350\275\254\346\215\242\345\231\250\343\200\221\351\200\211\346\213\251\350\276\223\345\205\245\346\225\260\347\232\204\350\277\233\345\210\266\357\274\210\344\272\214/\345\215\201/\345\215\201\345\205\255\357\274\211\357\274\214\350\276\223\345\205\245\345\276\205\350\275\254\346\215\242\347\232\204\346\225\260\357\274\214\347\202\271\345\207\273\345\274\200\345\247\213\350\275\254\346\215\242\357\274\214\344\274\232\347\224\237\346\210\220\347\233\270\345\272\224\347\232\204\344\272\214\343\200\201\345\215\201\343\200\201\345\215\201\345\205\255\350\277\233\345\210\266\350\241\250\347\244\272\343\200\202\350\213\245\347\255\224\346\241\210\345\274\202\345\270\270\357\274\214\345\217\257\350\203\275\346\230\257\345\215\201\350\277\233\345\210\266\346\225\260\350\266\205\350\277\207\344\272\206long long int\347\232\204\350\214\203\345\233\264\343\200\202", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Secondwindow: public Ui_Secondwindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SECONDWINDOW_H
